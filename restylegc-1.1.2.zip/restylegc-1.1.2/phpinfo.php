<?php
/* 
 * For debugging your PHP configuration.  
 * Put this on your web site somewhere and access the page via your web browser.
 * You will get version information, configuration settings, a list of installed modules, etc.
 */
phpinfo();
?>

