This archive folder contains old versions of the JavaScript and CSS files 
provided by Google.  These files are copyright by Google, Inc. and are subject
to their licenses and terms of service.  These files are here for archival
purposes as well as allowing the end-user to serve the files from their server.
This archive is included for convenience of the end-user.
